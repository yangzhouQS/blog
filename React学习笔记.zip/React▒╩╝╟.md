# React入门

## 概念

### 单页面应用

单页面应用(single-page application)，是一个应用程序，它可以加载单个 HTML 页面，以及运行应用程序所需的所有必要资源（例如 JavaScript 和 CSS）。与页面或后续页面的任何交互，都不再需要往返 server 加载资源，即页面不会重新加载。

你可以使用 React 来构建单页应用程序，但不是必须如此。React 还可用于增强现有网站的小部分，使其增加额外交互。用 React 编写的代码，可以与服务器端渲染的标记（例如 PHP）或其他客户端库和平共处。实际上，这也正是 Facebook 内部使用 React 的方式。

### Compiler（编译器）

JavaScript compiler 接收 JavaScript 代码，然后对其进行转换，最终返回不同格式的 JavaScript 代码。最为常见的使用示例是，接收 ES6 语法，然后将其转换为旧版本浏览器能够解释执行的语法。[Babel](https://babeljs.io/) 是 React 最常用的 compiler。

### JSX

JSX 是一个 JavaScript 语法扩展。它类似于模板语言，但它具有 JavaScript 的全部能力。JSX 最终会被编译为 `React.createElement()` 函数调用，返回称为 “React 元素” 的普通 JavaScript 对象。通过[查看这篇文档](https://react.docschina.org/docs/introducing-jsx.html)获取 JSX 语法的基本介绍，在[这篇文档]中可以找到 JSX 语法的更多深入教程。

React DOM 使用 camelCase（驼峰式命名）来定义属性的名称，而不使用 HTML 属性名称的命名约定。例如，HTML 的 `tabindex` 属性变成了 JSX 的 `tabIndex`。而 `class` 属性则变为 `className`，这是因为 `class` 是 JavaScript 中的保留字：

```
const name = 'Clementine';
ReactDOM.render(
  <h1 className="hello">My name is {name}!</h1>,
  document.getElementById('root')
);
```

### [元素](https://react.docschina.org/docs/rendering-elements.html)

React 元素是构成 React 应用的基础砖块。人们可能会把元素与广为人知的“组件”概念相互混淆。元素描述了你在屏幕上想看到的内容。React 元素是不可变对象。

```
const element = <h1>Hello, world</h1>;
```

通常我们不会直接使用元素，而是从组件中返回元素。

### [组件](https://react.docschina.org/docs/components-and-props.html)

React 组件是可复用的小的代码片段，它们返回要在页面中渲染的 React 元素。React 组件的最简版本是，一个返回 React 元素的普通 JavaScript 函数：

```
function Welcome(props) {
  return <h1>Hello, {props.name}</h1>;
}
```

组件也可以使用 ES6 的 class 编写：

```
class Welcome extends React.Component {
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }
}
```

组件可被拆分为不同的功能片段，这些片段可以在其他组件中使用。组件可以返回其他组件、数组、字符串和数字。根据经验来看，如果 UI 中有一部分被多次使用（Button，Panel，Avatar），或者组件本身就足够复杂（App，FeedStory，Comment），那么它就是一个可复用组件的候选项。组件名称应该始终以大写字母开头（`<Wrapper/>` **而不是** `<wrapper/>`）。有关渲染组件的更多信息，请参阅[这篇文档](https://react.docschina.org/docs/components-and-props.html#rendering-a-component)。

[`props`](https://react.docschina.org/docs/components-and-props.html)

`props` 是 React 组件的输入。它们是从父组件向下传递给子组件的数据。

记住，`props` 是只读的。不应以任何方式修改它们：

```
// 错误做法！
props.number = 42;
```

如果你想要修改某些值，以响应用户输入或网络响应，请使用 `state` 来作为替代。

`props.children`

每个组件都可以获取到 `props.children`。它包含组件的开始标签和结束标签之间的内容。例如：

```
<Welcome>Hello world!</Welcome>
```

在 `Welcome` 组件中获取 `props.children`，就可以得到字符串 `Hello world!`：

```
function Welcome(props) {
  return <p>{props.children}</p>;
}
```

对于 class 组件，请使用 `this.props.children` 来获取：

```
class Welcome extends React.Component {
  render() {
    return <p>{this.props.children}</p>;
  }
}
```

[`state`](https://react.docschina.org/docs/state-and-lifecycle.html#adding-local-state-to-a-class)

当组件中的一些数据在某些时刻发生变化时，这时就需要使用 `state` 来跟踪状态。例如，`Checkbox` 组件可能需要 `isChecked` 状态，而 `NewsFeed` 组件可能需要跟踪 `fetchedPosts` 状态。

`state` 和 `props` 之间最重要的区别是：`props` 由父组件传入，而 `state` 由组件本身管理。组件不能修改 `props`，但它可以修改 `state`。

对于所有变化数据中的每个特定部分，只应该由一个组件在其 state 中“持有”它。不要试图同步来自于两个不同组件的 state。相反，应当将其[提升](https://react.docschina.org/docs/lifting-state-up.html)到最近的共同祖先组件中，并将这个 state 作为 props 传递到两个子组件。

### [key](https://react.docschina.org/docs/lists-and-keys.html)

“key” 是在创建元素数组时，需要用到的一个特殊字符串属性。key 帮助 React 识别出被修改、添加或删除的 item。应当给数组内的每个元素都设定 key，以使元素具有固定身份标识。

只需要保证，在同一个数组中的兄弟元素之间的 key 是唯一的。而不需要在整个应用程序甚至单个组件中保持唯一。

不要将 `Math.random()` 之类的值传递给 key。重要的是，在前后两次渲染之间的 key 要具有“固定身份标识”的特点，以便 React 可以在添加、删除或重新排序 item 时，前后对应起来。理想情况下，key 应该从数据中获取，对应着唯一且固定的标识符，例如 `post.id`。

## Hook

<https://react.docschina.org/docs/hooks-intro.html>

### Hook 简介

*Hook* 是 React 16.8 的新增特性。它可以让你在不编写 class 的情况下使用 state 以及其他的 React 特性。

```
import React, { useState } from 'react';

function Example() {
  // 声明一个新的叫做 “count” 的 state 变量
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}
```

`useState` 是我们要学习的第一个 “Hook”，这个例子是简单演示。如果不理解也不用担心。





## 框架简介

### ReactJS简介
+ React 起源于 Facebook 的内部项目，因为该公司对市场上所有 JavaScript MVC 框架，都不满意，就决定自己写一套，用来架设 Instagram 的网站。做出来以后，发现这套东西很好用，**就在2013年5月开源了**。
+ 由于 React 的设计思想极其独特，属于革命性创新，性能出众，代码逻辑却非常简单。所以，越来越多的人开始关注和使用，认为它可能是将来 Web 开发的主流工具。
+ library
+ Framework


### 前端三大主流框架
+ Angular.js：出来最早的前端框架，学习曲线比较陡，NG1学起来比较麻烦，NG2开始，进行了一系列的改革，也开始启用组件化了；在NG中，也支持使用TS（TypeScript）进行编程；
+ Vue.js：最火的一门前端框架，它是中国人开发的，对我我们来说，文档要友好一些；
+ React.js：最流行的一门框架，因为它的设计很优秀；
+ windowsPhone 7    7.5   8   10


### React与vue.js的对比
#### 组件化方面
1. 什么是模块化：从 **代码** 的角度，去分析问题，把我们编程时候的业务逻辑，分割到不同的模块中来进行开发，这样能够**方便代码的重用**；
2. 什么是组件化：从 **UI** 的角度，去分析问题，把一个页面，拆分为一些互不相干的小组件，随着我们项目的开发，我们手里的组件会越来越多，最后，我们如果要实现一个页面，可能直接把现有的组件拿过来进行拼接，就能快速得到一个完整的页面， 这样方**便了UI元素的重用**；**组件是元素的集合体**；
3. 组件化的好处：
4. Vue是如何实现组件化的：.vue 组件模板文件，浏览器不识别这样的.vue文件，所以，在运行前，会把 .vue 预先编译成真正的组件；
 + template： UI结构
 + script： 业务逻辑和数据
 + style： UI的样式
5. React如何实现组件化：在React中实现组件化的时候，根本没有 像 .vue 这样的模板文件，而是，直接使用JS代码的形式，去创建任何你想要的组件；
 + React中的组件，都是直接在 js 文件中定义的；
 + React的组件，并没有把一个组件 拆分为 三部分（结构、样式、业务逻辑），而是全部使用JS来实现一个组件的；（也就是说：结构、样式、业务逻辑是混合在JS里面一起编写出来的）

#### 开发团队方面
+ React是由FaceBook前端官方团队进行维护和更新的；因此，React的维护开发团队，技术实力比较雄厚；
+ Vue：第一版，主要是有作者 尤雨溪 专门进行维护的，当 Vue更新到 2.x 版本后，也有了一个小团队进行相关的维护和开发；

#### 社区方面
+ 在社区方面，React由于诞生的较早，所以社区比较强大，一些常见的问题、坑、最优解决方案，文档、博客在社区中都是可以很方便就能找到的；
+ Vue是近两年才诞生开源出来的，所以，它的社区相对于React来说，要小巧一些，所以，可能有的一些坑，没人踩过；

#### 移动APP开发体验方面
+ Vue，结合 Weex 这门技术，提供了 迁移到 移动端App开发的体验（Weex，目前只是一个 小的玩具， 并没有很成功的 大案例；）
+ React，结合 ReactNative，也提供了无缝迁移到 移动App的开发体验（RN用的最多，也是最火最流行的）；



### 为什么要学习React
1. 设计很优秀，是基于组件化的，方便我们UI代码的重用；
2. 开发团队实力强悍，不必担心短更的情况；
3. 社区强大，很多问题都能找到对应的解决方案；
4. 提供了无缝转到 ReactNative 上的开发体验，让我们技术能力得到了拓展；增强了我们的核心竞争力



### React中几个核心的概念
#### 虚拟DOM（Virtual Document Object Model）

VDOM，也叫虚拟DOM，并不是什么高大上的新事物，它是仅存于内存中的DOM，因为还未展示到页面中，所以称为VDOM。



 + DOM的本质是什么：就是用JS表示的UI元素
 + DOM和虚拟DOM的区别：
   - DOM是由浏览器中的JS提供功能，所以我们只能人为的使用 浏览器提供的固定的API来操作DOM对象；
   - 虚拟DOM：并不是由浏览器提供的，而是我们程序员手动模拟实现的，类似于浏览器中的DOM，但是有着本质的区别；
 - 为什么要实现虚拟DOM：
 - 什么是React中的虚拟DOM：
 - 虚拟DOM的目的：
![虚拟DOM - 表格排序案例](assets/虚拟DOM引入图片.png)

#### Diff算法
 - tree diff:新旧DOM树，逐层对比的方式，就叫做 tree diff,每当我们从前到后，把所有层的节点对比完后，必然能够找到那些 需要被更新的元素；
 - component diff：在对比每一层的时候，组件之间的对比，叫做 component diff;当对比组件的时候，如果两个组件的类型相同，则暂时认为这个组件不需要被更新，如果组件的类型不同，则立即将旧组件移除，新建一个组件，替换到被移除的位置；
 - element diff:在组件中，每个元素之间也要进行对比，那么，元素级别的对比，叫做 element diff；
 - key：key这个属性，可以把 页面上的 DOM节点 和 虚拟DOM中的对象，做一层关联关系；
![Diff算法图](assets/Diff.png)

![1561799272871](assets/1561799272871.png)



### React项目的创建

1. 运行 `cnpm i react react-dom -S` 安装包
2. 在项目中导入两个相关的包：
```
// 1. 在 React 学习中，需要安装 两个包 react  react-dom
// 1.1 react 这个包，是专门用来创建React组件、组件生命周期等这些东西的；
// 1.2 react-dom 里面主要封装了和 DOM 操作相关的包，比如，要把 组件渲染到页面上
import React from 'react'
import ReactDOM from 'react-dom'
```
3. 使用JS的创建虚拟DOM节点：
```
    // 2. 在 react 中，如要要创建 DOM 元素了，只能使用 React 提供的 JS API 来创建，不能【直接】像 Vue 中那样，手写 HTML 元素
    // React.createElement() 方法，用于创建 虚拟DOM 对象，它接收 3个及以上的参数
    // 参数1： 是个字符串类型的参数，表示要创建的元素类型
    // 参数2： 是一个属性对象，表示 创建的这个元素上，有哪些属性
    // 参数3： 从第三个参数的位置开始，后面可以放好多的虚拟DOM对象，这写参数，表示当前元素的子节点
    // <div title="this is a div" id="mydiv">这是一个div</div>

    var myH1 = React.createElement('h1', null, '这是一个大大的H1')

    var myDiv = React.createElement('div', { title: 'this is a div', id: 'mydiv' }, '这是一个div', myH1)
```
4. 使用 ReactDOM 把元素渲染到页面指定的容器中：
```
    // ReactDOM.render('要渲染的虚拟DOM元素', '要渲染到页面上的哪个位置中')
    // 注意： ReactDOM.render() 方法的第二个参数，和vue不一样，不接受 "#app" 这样的字符串，而是需要传递一个 原生的 DOM 对象
    ReactDOM.render(myDiv, document.getElementById('app'))
```


## JSX语法
1. 如要要使用 JSX 语法，必须先运行 `cnpm i babel-preset-react -D`，然后再 `.babelrc` 中添加 语法配置；
2. JSX语法的本质：还是以 React.createElement 的形式来实现的，并没有直接把 用户写的 HTML代码，渲染到页面上；
3. 如果要在 JSX 语法内部，书写 JS 代码了，那么，所有的JS代码，必须写到 {} 内部；
4. 当 编译引擎，在编译JSX代码的时候，如果遇到了`<`那么就把它当作 HTML代码去编译，如果遇到了 `{}` 就把 花括号内部的代码当作 普通JS代码去编译；
5. 在{}内部，可以写任何符合JS规范的代码；
6. 在JSX中，如果要为元素添加`class`属性了，那么，必须写成`className`，因为 `class`在ES6中是一个关键字；和`class`类似，label标签的 `for` 属性需要替换为 `htmlFor`.
7. 在JSX创建DOM的时候，所有的节点，必须有唯一的根元素进行包裹；
8. 如果要写注释了，注释必须放到 {} 内部



## 创建组件

### 第一种基本组件的创建方式

![1561802456105](assets/1561802456105.png)





#### 父组件向子组件传递数据

#### 属性扩散




#### 将组件封装到单独的文件中



### 第二种创建组件的方式
#### 了解ES6中class关键字的使用


#### 基于class关键字创建组件
+ 使用 class 关键字来创建组件
```
class Person extends React.Component{
    // 通过报错提示得知：在class创建的组件中，必须定义一个render函数
    render(){
        // 在render函数中，必须返回一个null或者符合规范的虚拟DOM元素
        return <div>
            <h1>这是用 class 关键字创建的组件！</h1>
        </div>;
    }
}
```

### 两种创建组件方式的对比
1. 用构造函数创建出来的组件：专业的名字叫做“无状态组件”
2. 用class关键字创建出来的组件：专业的名字叫做“有状态组件”

> 用构造函数创建出来的组件，和用class创建出来的组件，这两种不同的组件之间的**本质区别就是**：有无state属性！！！
> 有状态组件和无状态组件之间的本质区别就是：有无state属性！



## React基础知识

### 目录结构分析 





### 创建组件

![1561803260600](assets/1561803260600.png)



### JSX语法

<https://www.jianshu.com/p/813aa32555b8>

#### 求值表达式

要使用 JavaScript 表达式作为属性值，只需把这个表达式用一对大括号 ( { } ) 包起来，不要用引号 ( " " )。
 在编写JSX时，在 { } 中不能使用语句（if语句、for语句等等），但可以使用求值表达式，这本身与JSX没有多大关系，是JS中的特性，它是会返回值的表达式。我们不能直接使用语句，但可以把语句包裹在函数求值表达式中运用。

#### 条件判断的写法

你没法在JSX中使用 if-else 语句，因为 JSX 只是函数调用和对象创建的语法糖。在 { } 中使用，是不合法的JS代码，不过可以采用三元操作表达式

```
var HelloMessage = React.createClass({ 
  render: function() { 
    return <div>Hello {this.props.name ？ this.props.name : "World"}</div>; 
  }
});
ReactDOM.render(<HelloMessage name="xiaowang" />, document.body);
```

可以使用比较运算符“ || ”来书写，如果左边的值为真，则直接返回左边的值，否则返回右边的值，与if的效果相同。

```
var HelloMessage = React.createClass({ 
  render: function() { 
    return <div>Hello {this.props.name || "World"}</div>; 
  }
});
```

#### 函数表达式

（ ）有强制运算的作用

```
var HelloMessage = React.createClass({ 
  render: function() { 
    return <div>Hello { 
    （function(obj){ 
        if(obj.props.name) 
          return obj.props.name 
        else 
          return "World" 
      }(this)) 
    }</div>; 
  }
});
ReactDOM.render(<HelloMessage name="xiaowang" />, document.body);
```

外括号“ ）”放在外面和里面都可以执行。唯一的区别是括号放里面执行完毕拿到的是函数的引用，然后再调用“function(){}(this)()”；括号放在外面的时候拿到的事返回值。

#### 组件的生命周期

组件的生命周期分成三个状态：

```
* Mounting：已插入真实 DOM
* Updating：正在被重新渲染
* Unmounting：已移出真实 DOM
```

React 为每个状态都提供了两种处理函数，will 函数在进入状态之前调用，did 函数在进入状态之后调用，三种状态共计五种处理函数。

```
* componentWillMount()
* componentDidMount()
* componentWillUpdate(object nextProps, object nextState)
* componentDidUpdate(object prevProps, object prevState)
* componentWillUnmount()
```

此外，React 还提供两种特殊状态的处理函数。

```
* componentWillReceiveProps(object nextProps)：已加载组件收到新的参数时调用
* shouldComponentUpdate(object nextProps, object nextState)：组件判断是否重新渲染时调用
```





#### 注释

JSX 里添加注释很容易；它们只是 JS 表达式而已。你只需要在一个标签的子节点内(非最外层)小心地用 {} 包围要注释的部分。

```
{/* 一般注释, 用 {} 包围 */}
```



### 绑定数据

{}

### 绑定对象





### 绑定属性( 绑定class  绑定style)

class绑定需要使用className

for绑定需要使用htmlFor

```
<li>绑定属性 : <a href={ this.state.url }>百度</a></li>
<li>class绑定 <div className='red' className={ this.state.bg }>green</div></li>
<li title={ this.state.xx || '未知数据' }>title绑定</li>
<li>
          for绑定需要使用htmlFor
          <label htmlFor="userName">userName</label>
          <input type="text" id="userName"/>
</li>
```

style绑定

```
style : {
  background : '#666',
},
```

```
<li style={ {'color' : 'red'} } style={ this.state.style }>行内样式</li>
```





### 引入图片

```
import img1 from '../assets/img/1.jpg';
```

```
<img src={ img1 } width="120" height="120" alt=""/>
<img src={ require('../assets/img/1.jpg') } width="120" height="120" alt=""/>
```





### 循环数组渲染数据

循环渲染数据需要绑定key

```
list : [ {
  name : '李四',
  age : 26,
  sex : '男',
}, {
  name : '大牛',
  age : 22,
  sex : '男',
}, {
  name : '小丽',
  age : 14,
  sex : '女',
} ],
```

```
{ this.state.list.map((value, index) => {
  return (<li key={ index }>{ value.name } - { value.age } - { value.sex }</li>);
}) }
```

注意的点：
1、所有的模板要被一个根节点包含起来
2、模板元素不要加引号
3、用大括号{}绑定数据
4、循环数据要加key
5、img要加alt
6、绑定属性
class 要变成 className
for 要变成 htmlFor
style属性写法

```
<div style={{'color':'red'}}>行内样式1双大括号</div>
<div style={this.state.style}>行内样式2  style="{'{this.state.style}'}"</div>
```



### 事件 方法

#### 获取state的值

```
import React from 'react';

class Handler extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      list : [ 1, 2, 3 ],
      name : 'xianJs',
      age : '26岁',
    };
    this.getName = this.getName.bind(this);
  }

  getList(params){
    console.log('params', params);
  }

  //箭头函数
  getAge = () => {
    console.log(this.state.age);
  };

  //在构造函数绑定this
  getName(){
    console.log(this.state.name);
  }

  render(){
    return (<div>
      {/*第一种绑定this*/ }
      <button onClick={ this.getList.bind(this) }>点击事件</button>
      <button onClick={ this.getAge }>获取age</button>
      <button onClick={ this.getName }>获取name</button>
    </div>);
  }

}

export default Handler;
```



```
绑定事件处理函数this的几种方法：
第一种方法：
  	run(){

        	alert(this.state.name)
  	}
  	<button onClick={this.run.bind(this)}>按钮</button>



第二种方法：
	构造函数中改变

	this.run = this.run.bind(this);


 	run(){

        	alert(this.state.name)
 	 }
 	<button onClick={this.run>按钮</button>



第三种方法：
	 run=()=> {
    		alert(this.state.name)
 	 }

	<button onClick={this.run>按钮</button>
```



#### 点击事件传递参数

```
//修改state的值,传递参数
setName = (e, name) => {
  console.log(name);
  this.setState({
                  name : name,
                  list : [ 1, 5, 6 ],
                });
};
//传递参数2
setAge = (age) => {
  return (e) => {
    this.setState({
                    age : age,
                  });
    console.log(age);
  };
};
//绑定this的方式传递参数
setList = (list) => {
  console.log(list);
};

render(){
  return (<div>
    <p>name = { this.state.name } <br/> age={ this.state.age }</p>
    <button onClick={ (e) => this.setName(e, '北京天安门') }>传递参数1
    </button>
    <button onClick={ this.setAge(22) }>传递参数2</button>
    <button onClick={ this.setList.bind(this, [ 4, 3, 2, 1 ]) }>传递参数3</button>
  </div>);
}
```





### React定义方法

```
constructor(props){
  super(props);
  this.state = {
    list : [ 1, 2, 3 ],
    name : 'xianJs',
    age : '26岁',
  };
  this.getName = this.getName.bind(this);
}

getList(params){
  console.log('params', params);
}

//箭头函数
getAge = () => {
  console.log(this.state.age);
};

//在构造函数绑定this
getName(){
  console.log(this.state.name);
}
```



### 获取数据



### 改变数据

```
//修改state的值
setName = () => {
  this.setState({
                  name : '北京',
                  list : [ 1, 5, 6 ],
                });
};

render(){
  return (<div>
    <p>name = { this.state.name } <br/> list={ this.state.list }</p>
    <button onClick={ this.setName }>修改name值</button>
  </div>);
}
```



### 执行方法传值

```
class Handler extends React.Component{
  constructor(props){
    super(props);
    this.state = {
      list : [ 1, 2, 3 ],
      name : 'xianJs',
      age : '26岁',
    };
  }

  //修改state的值,传递参数
  setName = (e, name) => {
    console.log(name);
    this.setState({
                    name : name,
                    list : [ 1, 5, 6 ],
                  });
  };
  //传递参数2
  setAge = (age) => {
    return (e) => {
      this.setState({
                      age : age,
                    });
      console.log(age);
    };
  };
  //绑定this的方式传递参数
  setList = (list) => {
    console.log(list);
  };

  render(){
    return (<div>
      <p>name = { this.state.name } <br/> age={ this.state.age }</p>
      <button onClick={ (e) => this.setName(e, '北京天安门') }>传递参数1
      </button>
      <button onClick={ this.setAge(22) }>传递参数2</button>
      <button onClick={ this.setList.bind(this, [ 4, 3, 2, 1 ]) }>传递参数3</button>
    </div>);
  }

}
```

### 事件对象

```
setAge = (e,age) => {
  console.log(e,age);
  /*buttonDOM节点*/
  console.log(e.target.getAttribute('uid'));//获取自定义属性
  e.target.style.background = 'red';
};

render(){
  return (<div>
    <button uid="666" onClick={ (e) => {this.setAge(e,16);} }>事件对象获取</button>
  </div>);
}
```



### 表单事件 

```
<p>userName = { this.state.userName }</p>
<input type="text" placeholder="userName" onChange={ this.inputChange }/>
<button uid="666" onClick={ this.getName }>获取表单值</button>

  inputChange = (e) => {
    //将获取到的表单value值赋值给this.state.userName
    this.setState({
      userName : e.target.value,
    });
    console.log(e.target.value);
  };
```



### ref双向数据绑定

```
<input type="text" ref="userAge" onChange={ this.inputAge }/>

inputAge = (e) => {
    //refs对象获取DOM节点
    console.log(this.refs.userAge.value);
  };
```



### 键盘事件

```
<input type="text" onKeyDown={ this.inputKeyDown }/>

inputKeyDown = (e) => {
    console.log(e.keyCode);
  };
```







### 表单

```
约束性和非约束性组件:

      非约束性组:<input type="text" defaultValue="a" />   这个 defaultValue 其实就是原生DOM中的 value 属性。
      
      这样写出的来的组件，其value值就是用户输入的内容，React完全不管理输入的过程。


      约束性组件：<input value={this.state.username} type="text" onChange={this.handleUsername}  /> 

              这里，value属性不再是一个写死的值，他是 this.state.username, this.state.username 是由 this.handleChange 负责管理的。

      
              这个时候实际上 input 的 value 根本不是用户输入的内容。而是onChange 事件触发之后，由于 this.setState 导致了一次重新渲染。不过React会优化这个渲染过程。看上去有点类似双休数据绑定
       
```



<https://www.cnblogs.com/yuyujuan/p/10124025.html>

```
import React,{ Component } from 'react';

class Form extends Component{
  constructor(props){
    super(props);
    this.state = {
      userData : {
        name  : '',
        age   : '',
        sex   : '',
        hobby : [ 
        { id    : 0,label : '篮球', },{ id    : 1,label : '游泳', },
        { id    : 2,label : '蹴鞠', },{ id    : 3,label : '棒球', } ],
        city  : [ 
        { id   : 0,city : '南京', },{ id   : 1,city : '北京', },
        { id   : 2,city : '海南', },{ id   : 3,city : '新疆', } ],
      },
    };
  }

  render(){
    return (<div>
      <form action="" onSubmit={ this.handleSubmit }>
        <p>姓名: <input type="text" onChange={ this.changName } value={ this.state.userData.name }/></p>
        <p>年龄: <input type="text" onChange={ this.changAge } value={ this.state.userData.age }/></p>
        <p>性别:
          <input type="radio" name="sex" value='1' onChange={ this.changSex }/> 男 <br/>
          <input type="radio" name="sex" value='0' onChange={ this.changSex }/> 女 <br/>
        </p>
        <p>
          城市: <select value={ this.state.userData.selectCity } onChange={ this.changCity }>
          { this.state.userData.city.map(item => {
            return <option key={ item.id }>{ item.city }</option>;
          }) }
        </select>
        </p>
        <p><input type="submit" value="数据提交保存"/></p>
      </form>
    </div>);
  }

  changName = (e) => {
    console.log(e.target.value);
    let data = Object.assign({},this.state.userData,{
      name : e.target.value,
    });
    this.setState({
      userData : data,
    });
  };

  changAge = (e) => {
    let data = Object.assign({},this.state.userData,{
      age : e.target.value,
    });
    this.setState({
      userData : data,
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();//阻止表单的默认提交事件
    console.log(this.state.userData);
  };

  changSex = (e) => {
    let data = Object.assign({},this.state.userData,{
      sex : e.target.value,
    });
    this.setState({
      userData : data,
    });
  };

  changCity = (e) => {
    let data = Object.assign({},this.state.userData,{
      selectCity : e.target.value,
    });
    this.setState({
      userData : data,
    });
  };
}


export default Form;
```

![复选框](assets/1561909183369.png)

<https://www.cnblogs.com/yuyujuan/category/1329267.html>

![1561909531569](assets/1561909531569.png)



## 组件通信

<https://www.cnblogs.com/yuyujuan/p/10125283.html>

### 什么是组件？

React通过组件的思想，将界面拆分成一个个可复用的模块，每一个模块就是一个React 组件。一个React 应用由若干组件组合而成，一个复杂组件也可以由若干简单组件组合而成。

React 组件可以用好几种方式声明，可以是一个包含 render() 方法的类，也可以是一个简单的函数，不管怎么样，它都是以props作为输入，返回 React 元素作为输出。

### 组件的作用

React组件最核心的作用是返回React元素。

这里你也许会问：React元素不应该是由React.createElement() 返回的吗？ 

其实React组件就是调用React.createElement()，返回React元素，供React内部将其渲染成最终的页面DOM。

```
//函数式
function Welcome(props) {
  return <h1>Hello, {props.name}</h1>;
}
```



```
//类定义
class Welcome extends React.Component {
    //render函数并不做实际的渲染动作，他只是返回一个JSX
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }
}
```

无论是函数式组件，还是类定义组件，最终组件return的都是React元素，而return的React元素(JSX)则又调用了 React.createElement()

从return React元素到组件被实际渲染 挂到DOM树上 中间还有很复杂的过程。 
比如：在类组件中render函数被调用完之后，componentDidMount函数并不是会被立刻调用。componentDidMount被调用的时候，render函数返回的东西已经引发了渲染，组件已经被『装载』到了DOM树上

其实，使用类定义的组件，render方法是唯一必需的方法，其他组件的生命周期方法都只不过是为render服务而已，都不是必需的。



### 组件创建方式

目前，React支持三种方式来定义一个组件，分别是： 
- ES5的React.createClass方式； 
- ES6的React.Component方式； 
- 无状态的函数组件方式。

组件是由元素构成的。元素数据结构是普通对象，而组件数据结构是类或纯函数。



- 类 组件：class extends React.Component()
- js函数式组件
- React.createClass()

1、类 组件 
相比于函数式组件功能更强大。它有state，以及不同的生命周期方法，可以让开发者能够在组件的不同阶段（挂载、更新、卸载），对组件做更多的控制。 

类组件可能是无状态组件，也可能是有状态组件。[详见：组件分类](https://www.jianshu.com/p/e438d8e32ef3)

```
//组件名首字母必须大写
class Welcome extends React.Component{
  //添加其他事件函数这么加：myWay(){···}
  render(){
    return (<div>my name is {this.props.name},{this.props.age}</div>);
  }
};
```

2、函数式组件 
JavaScript 函数构建的组件一定是无状态组件。它能传入props和context两个参数，没有state，除了render()，没有其它生命周期方法。 

但正是这样，函数组件才更加专注和单一，它只是一个返回React 元素的函数，只关注对应UI的展现。函数组件接收外部传入的props，返回对应UI的DOM描述。

```
//组件名称总是以大写字母开始。
//定义模版的函数名首字母必须大写
function Welcome(props){
  //添加其他事件函数这么加：function otherFun(){·····}
  return <div>my name is {props.name},{props.age}</div>;
}
```

3 、**React.createClass()**

```
/*组件首字母必须大写，eg:Greeting的G*/
var Greeting = React.createClass({
  render: function() {
    return <h1>Hello, {this.props.name}</h1>;
  }
});
```

创建组件时需注意： 
1、给组件命名时，组件首字母必须大写 
2、render()方法的return 里，`只能有一个html父标签`，所以涉及到多个html标签时，必须外面再嵌套个父标签



### React中的组件



### 父子组件



### React props父组件给子组件传值

<https://www.cnblogs.com/yuyujuan/p/10125283.html>

```
父组件
import Parent from './Parent';

class Content extends Component{
  constructor(props){
    super(props);
    this.state = {
      url : {
        url  : 'http://www.baidu.com',
        name : '百度',
      },
    };
  }

  render(){
    return (<div>
      {/*父组件*/ }
      <Parent url={ this.state.url }></Parent>
    </div>);
  }
}

//子组件
class Parent extends Component{
  constructor(props){
    super(props);
    this.state = {};
  }

  render(){
    return (<div>
      <p><a href={ this.props.url.url }>{ this.props.url.name }</a></p>
    </div>);
  }
}

```

### 子组件调用父组件方法

```
//父组件
  render(){
    return (<div>
      {/*父组件*/ }
      <Parent say={ this.sayHello }></Parent>
    </div>);
  }

  sayHello = (params) => {
    //父组件接受子组件传递的数据
    console.log('父组件的sayHello方法');
    console.log(params);
  };

//子组件
render(){
    return (<div>
      {/*<p><a href={ this.props.url.url }>{ this.props.url.name }</a></p>*/ }
      <button onClick={ this.props.say.bind(this,'xianjs') }>子组件调用父组件的方法</button>
    </div>);
  }
```





### 父组件中通过refs获取子组件属性和方法

```
//父组件
render(){
  return (<div>
    <Parent ref="parent"></Parent>
    {/*父组件*/ }
    <button onClick={ this.getParentData }>执行父组件的方法和获取子组件的数据</button>
  </div>);
}

getParentData = () => {
  //执行子组件的方法
  this.refs.parent.getParentName();
  //获取子组件的数据
  console.log(this.refs.parent.state.title);
};


//子组件
  getParentName = () => {
    console.log(this.state);
  };

  render(){
    return (<div>
      <h1>子组件 parent</h1>
    </div>);
  }
```

![1561911763687](assets/1561911763687.png)

### 在子组件中获取整个父组件

通过在父组件中获取整个子组件的实例，从而获取了组件的数据和方法，其实，在子组件中，也可以获取整个父组件的实例，从而获取父组件的数据和方法。

首要，父组件中定义数据和方法，并在调用子组件的时候，定义一个属性，传入this，即当前组件。

![img](assets/1304208-20181215224314424-1899360085.png)

然后在子组件中，可以直接使用这些数据和方法

![img](assets/1304208-20181215224415249-1324955327.png)

当然了，这种情况下也可以很方便的将子组件的数据传递到父组件了，而不在需要通过在父组件中获取整个子组件了。

 ![img](assets/1304208-20181215225203832-103892753.png)

![img](assets/1304208-20181215225234971-1326620637.png)





子组件中div里面的数据依赖于父组件传递过来的数据，那么当父组件没有给子组件传递数据时，子组件div里面就没有了数据了，这显然也不符合我们的预期，我们希望给子组件一个默认值，当父组件传递了数据过来时，就显示父组件传递的数据，当父组件没有传递数据时，子组件也能显示自己的默认值，这就时今天要说的defaultProps。

### defaultProps

 defaultProps的用法就是，在父子组件传值中，如果父组件调用子组件的时候不给子组件传值，则可以在子组件中使用defaultProps定义的默认值。具体使用方法如下：


![img](assets/1304208-20181215231330263-1706873911.png)

当父组件中没有传递数据时，显示的就是默认值，

 ![img](assets/1304208-20181215231416723-1013277858.png)

![img](assets/1304208-20181215231425567-1727731492.png)

当父组件中传递了数据时，显示的就是传递进来的数据值。

![img](assets/1304208-20181215231536654-356881570.png)

![img](assets/1304208-20181215231546239-1061704465.png)



### propTypes

在父子组件数据传递中，propTypes也经常被用到，用于在子组件中限定子组件希望得到的数据类型。

在使用的时候，首先需要引入，然后再定义相关数据的类型：

![img](assets/1304208-20181215232634597-1077660232-1561912160881.png)

那么当父组件传递的数据不是被期待的数据类型时，数据依然会显示，但是会给出一个警告：

![img](assets/1304208-20181215232808080-583909351-1561912160887.png)

![img](assets/1304208-20181215232828638-1210830497-1561912160895.png)

<https://www.cnblogs.com/yuyujuan/p/10125392.html>



## React生命周期函数

<https://www.cnblogs.com/yuyujuan/p/10125547.html>

在react中，生命周期函数指的是组件在加载前，加载后，以及组件更新数据和组件销毁时触发的一系列方法。通常分为以下几类：

1. 组件加载的时候触发的函数：constructor 、componentWillMount、 render 、componentDidMount
2. 组件数据更新的时候触发的函数：shouldComponentUpdate、componentWillUpdate、render、componentDidUpdate
3. 在父组件里面改变props传值的时候触发的函数：componentWillReceiveProps
4. 组件销毁的时候触发的函数：componentWillUnmount

### 组件加载

![img](assets/1304208-20181216002351909-1141036187.png)

 ![img](assets/1304208-20181216002415521-1976627971.png)

当然了，在这个里面，构造函数和render并不属于生命周期函数部分，这里将它们放在一起，只是为了更好的展示函数的执行顺序。

需要注意的是，componentDidMount是组件挂在完成的时候触发的生命周期函数，所以通常**将DOM操作和数据请求都放在componentDidMount里面**。

###  组件数据更新

![img](assets/1304208-20181216003826606-1927286881.png)

当我们点击按钮，更改组件数据时，会依次触发上面的函数。

![img](assets/1304208-20181216004020978-248768668.png)

这个里面组要注意的是，shouldComponentUpdate表示是否更新数据，只有当返回true的时候才会执行更新数据的操作。

### 组件销毁

要控制组件的销毁，可以在父组件中，通过一个标志数据的布尔值来控制是否加载该组件，然后通过点击事件改变该标志数据的值，从而控制组件的加载和销毁。

![img](assets/1304208-20181216005838395-2072849002.png)

然后就可以在子组件中监听组件的加载和销毁了。

![img](assets/1304208-20181216005932846-1919794349.png)

![img](assets/1304208-20181216005948861-473660691.png)

### 父组件改变传值

父组件改变传值的时候，会触发相应的生命周期函数，因为数据的改变，也会触发组件数据更新的相关函数。

![img](assets/1304208-20181216010838114-615626758.png)

![img](assets/1304208-20181216010909005-473906798.png)

![img](assets/1304208-20181216010920604-1461213166.png)

当我们点击按钮改变父组件的传值的时候，相关函数的触发顺序如下：

![img](assets/1304208-20181216011154503-247861771.png)

这里需要说明的是shouldComponentUpdate这个函数，它有两个参数，当在组件内部改变数据的时候，第二个参数是改变后的数据值，当在父组件中改变数据的时候，第一个参数是改变后的值。

 

## react-router 4.x

<https://www.cnblogs.com/yuyujuan/p/10128703.html>

本次主要总结react中的路由的使用，实现让根组件根据用户访问的地址动态挂载不同的组件。

## 1，创建项目

首先使用命令 npx create-react-app react-router创建项目，然后npm install下载相关依赖，再按照之前的文件目录整理src文件夹，最后再components文件夹下面新建两个组件Home.js和News.js。

![img](assets/1304208-20181216212813180-1106725879.png)

![img](assets/1304208-20181216213836327-219706908.png) ![img](assets/1304208-20181216213856556-839718880.png)

## 2，安装和引入路由

安装和引入路由可以分为以下几步：

1. 安装路由：在项目根目录执行命令： **npm install react-router-dom --save**进行安装
2. 根组件进行引入**import { BrowserRouter as Router, Route, Link } from "react-router-dom"**
3. 修改根组件文件App.js：在根元素中使用<Router>标签对路由组件进行包裹，然后使用组件。

![img](assets/1304208-20181216214248462-205994328.png)

根据上面的路由配置，当启动项目的时候，显示的是Home组件里面的内容，当我们更改地址栏，在其后面加入/news的后缀以后，就会显示News组件的内容。

![img](assets/1304208-20181216214832430-1929855062.png) ![img](assets/1304208-20181216214858343-454796041.png)

在Home组件路由配置中，多了一个单词exact，这个意思是严格匹配，如果去掉这个单词，那么当在地址改为http://localhost:3000/news的时候，就会通过加载两个组件，因为/news也能匹配‘/’这个路径。

 ![img](assets/1304208-20181216215109023-1034847029.png)

## 3，使用路由

我们在引入路由的时候，一共引入了三个组件Router, Route, Link，接下来及来使用这最后一个组件。

在实际运用中，并不会通过手动修改地址栏来进行页面切换，一般都是通过点击事件触发的，在react中，可以借助Link实现a标签进行地址跳转的功能，如下所示，只需要稍微修改根组件App.js就可以了。

![img](assets/1304208-20181216215930996-61214045.png)

![img](assets/1304208-20181216215942268-104112016.png)

现在当我们点击不同的标签，就会加载不同的页面了。下面贴出app.js的代码：

[![复制代码](assets/copycode.gif)](javascript:void(0);)

```
import React, { Component } from 'react';
import './assets/css/App.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Home from './components/Home';
import News from './components/News';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Router>
          <div> 
            <header className="title">  
              <Link to="/">首页</Link>
              <Link to="/news">新闻</Link>
            </header>
            <Route exact path="/" component={Home} />
            <Route path="/news" component={News} />                    
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
```



## 路由传值

<https://www.cnblogs.com/yuyujuan/p/10129098.html>

## React数据请求

https://www.cnblogs.com/yuyujuan/p/10134020.html

## React路由模块化

https://www.cnblogs.com/yuyujuan/p/10146421.html



## [redux & react-redux](https://www.cnblogs.com/yuyujuan/p/10427379.html)

在vue中，可以使用vuex进行数据管理，在react中，可以使用redux进行数据管理。redux主要由Store、Reducer和Action组成：

- Store：状态载体，访问状态、提交状态、监听状态变更
- Reducer：状态更新具体执行者，纯函数
- Action：存放数据的对象，即消息的载体，只能被别人操作，自己不能进行任何操作

## 简单使用

 在redux中，首先需要了解的是store，所有的数据都在这一个数据源里面进行管理，具有全局唯一性，但是redux本身和react并没有直接的联系，可以单独使用，复杂的项目才需要redux来管理数据，简单的项目，state+props+context就足够了。

例如，我们想要实现一个简单的累加器，就需要以下几步：

1. 用来存储数据的store，store里面的state是数据放置的位置
2. 通过dispatch一个action来提交对数据的修改
3. 请求提交到reducer函数里，根据传入的action和state，返回新的state

首先新建项目，然后执行命令npm install redux --save安装redux。

其次，在src文件夹下面新建store.js，创建store，然后根据action的不同类型，执行不同的操作：

store.js

[![复制代码](assets/copycode-1561912445763.gif)](javascript:void(0);)

```
import {createStore} from 'redux';

const counterReducer = (state = 0, action) => {
    switch(action.type){
        case 'add':
            return state + 1;
        case 'minus':
            return state - 1;
        default:
            return state;
    }
}

export default createStore(counterReducer)
```

[![复制代码](https://common.cnblogs.com/images/copycode.gif)](javascript:void(0);)

然后在components文件夹下面新建Test.js组件，并在组件中引入store.js

Test.js

[![复制代码](https://common.cnblogs.com/images/copycode.gif)](javascript:void(0);)

```
import React, {Component} from 'react'
import store from '../store'

class Test extends Component{
    render(){
        return (
            <div>
                <p>{store.getState()}</p>
                <button onClick={()=>store.dispatch({type:'add'})}> + </button>
                <button onClick={()=>store.dispatch({type:'minus'})}> - </button>
            </div>
        )
    }
}

export default Test;
```



最后使用组件，使用组件分两步：初始化渲染时，需要请求初始化的数据；后面每次数据改变时，重新加载数据。

index.js

```
// 初始化执行
ReactDOM.render(<Test />, document.getElementById('root'));
// 每次发生变化时执行
store.subscribe(()=>{
    ReactDOM.render(<Test />, document.getElementById('root'));
})
```



## react-redux

如果在大型项目中，我们每次都在需要使用的地方重新调用render，会十分麻烦，所以，需要使用更简洁的方法：react-redux，react-redux提供了两个api：提供数据的顶级组件Provider和提供数据与方法的高阶组件connect。

首先，要实现react-redux，需要先进行安装：npm install react-redux --save

 其次，既然要用到高阶组件，就需要使用高阶组件装饰器：npm install --save-dev babel-plugin-transform-decorators-legacy，具体的可以参考前面的[react高阶组件](https://www.cnblogs.com/yuyujuan/p/10367048.html)。

最后，来改写上面的累加器组件。

1，在index.js中引入Provider组件，并进行相应的修改，这样，后面就不需要再每个需要的页面多次引入store.js了，更不用在每次操作了数据以后重新render。

index.js

```
import store from './store';
import Test from './components/Test';
import {Provider} from 'react-redux'


ReactDOM.render((
    <Provider store={store}>
        <Test />
    </Provider>
), document.getElementById('root'));

serviceWorker.unregister();
```



2，在Test.js页面，重新更改写法，使用高阶组件connect来提供数据和方法：



```
import React, {Component} from 'react'
import { connect } from "react-redux";

@connect(
  state => ({ num: state }), // 状态映射
  {
    add: () => ({ type: "add" }),
    minus: () => ({ type: "minus" })
  }
)

class Test extends Component{
    render(){
        return (
            <div>
                <p>{this.props.num}</p>
                <button onClick={()=>this.props.add()}> + </button>
                <button onClick={()=>this.props.minus()}> - </button>
            </div>
        )
    }
}

export default Test;
```















## 一个小案例，巩固有状态组件和无状态组件的使用

### 通过for循环生成多个组件
1. 数据：
```
CommentList = [
    { user: '张三', content: '哈哈，沙发' },
    { user: '张三2', content: '哈哈，板凳' },
    { user: '张三3', content: '哈哈，凉席' },
    { user: '张三4', content: '哈哈，砖头' },
    { user: '张三5', content: '哈哈，楼下山炮' }
]
```

### style样式

## 总结
理解React中虚拟DOM的概念
理解React中三种Diff算法的概念
使用JS中createElement的方式创建虚拟DOM
使用ReactDOM.render方法
使用JSX语法并理解其本质
掌握创建组件的两种方式
理解有状态组件和无状态组件的本质区别
理解props和state的区别

## 相关文章
+ [React数据流和组件间的沟通总结](http://www.cnblogs.com/tim100/p/6050514.html)
+ [单向数据流和双向绑定各有什么优缺点？](https://segmentfault.com/q/1010000005876655/a-1020000005876751)
+ [怎么更好的理解虚拟DOM?](https://www.zhihu.com/question/29504639?sort=created)
+ [React中文文档 - 版本较低](http://www.css88.com/react/index.html)
+ [React 源码剖析系列 － 不可思议的 react diff](http://blog.csdn.net/yczz/article/details/49886061)
+ [深入浅出React（四）：虚拟DOM Diff算法解析](http://www.infoq.com/cn/articles/react-dom-diff?from=timeline&isappinstalled=0)
+ [一看就懂的ReactJs入门教程（精华版）](http://www.cocoachina.com/webapp/20150721/12692.html)
+ [CSS Modules 用法教程](http://www.ruanyifeng.com/blog/2016/06/css_modules.html)
+ [将MarkDown转换为HTML页面](http://blog.csdn.net/itzhongzi/article/details/66045880)
+ [win7命令行 端口占用 查询进程号 杀进程](https://jingyan.baidu.com/article/0320e2c1c9cf0e1b87507b26.html)