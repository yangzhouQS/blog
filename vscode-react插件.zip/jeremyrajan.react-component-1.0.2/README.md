# React Component

Creates a react component code according to file name.

## Usage

Launch the command pallete and look for `Create React Component`. That should create the component code for you in the current file.
If the file is Untitled, the default name `MyComponent` is used.

More features and lifecycle hooks will be added soon.
