## [2.0.3 - Added]
Add react story snippet `rstory`

## [2.0.2 - Added]
Add react-native story snippet `rnstory`

## [2.0.1 - Fixed]
Fix issue with naming component

## [2.0.0 - Added]

- Now snippet will interfer the filename in component creation

## [1.9.2 - Fixed]

- Fix import proptypes - By [freddydumont](https://github.com/freddydumont)

## [1.9.1 - Added]

- Add `ednl` Eslint Disable Next Line
- Add `imro` Import react as object, for typescript

## [1.9.0 - Added]

- add `tt` for jest test

## [1.8.0 - Added]

Updated for React 16.3

- Add Create Context `cct`
- Add getDerivedStateFromProps `gds`

## [1.7.3 - Added]

- Add import PropTypes

## [1.7.0 - Added]

- Add PureComponent Class `pcs`
- Add PureComponent Class with Constructor `pccs`
- Add Component Class FlowType `ccsf`
- Add PureComponent Class FlowType `pcsf`

## [1.6.0 - Added]

- Add Component Class with Constructor

## [1.5.0 - Added]

- Add shouldComponentUpdate
- Add FlowFixMe for flow user

## [1.4.0 - Added]

- Add import PureComponent for react

## [1.3.0 - Added]

- Add React-Nativr StyleSheet

## [1.2.0 - Added]

- Add ComponentDidCatch

## [1.1.0 - Added]

- Add Component Class With Redux

## [1.0.1 - Added]

- Add stateless component return

## [0.3.4 - ADDED]

- ComponentWillReceiveProps - By [aestrro](https://github.com/aestrro)

## [0.3.3 - ADDED]

- Test Describe
- Test It

## [0.3.0 - ADDED]

- Add console.log

## [0.2.2 - Fixed]

- Redux pure function semicolon

## [0.2.1 - ADDED]

- Redux pure function
- Redux pure function const
- Comment Big Block

## [0.2.0 - ADDED]

- Export Styled-Components
- Export Default Styled-Components

## [0.1.0 - ADDED]

- Styled-Components and Styled-Components/Native

## [0.0.6 - ADDED]

- Export default Component Class
- Redux Pure Function

## [0.0.5 - ADDED]

- ComponentDidUpdate

## [0.0.4 - ADDED]

- ComponentWillUnmount
- Styled Component

## [0.0.3 - ADDED]

- Add Stateless Component Function
